# pudding-pack
this is a private project only started bacause i was bored.
shouldnt be taken too serious.
Only things edited that you would need for an anarchy server.
Last edited  16th of April 2021
